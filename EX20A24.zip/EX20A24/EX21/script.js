function Maiuscula(texto){
    texto.value = texto.value.toUpperCase();
}
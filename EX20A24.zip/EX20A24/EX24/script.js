function mostrarFrete(){
    var frete = document.formulario.rfrete.value;
    alert(frete);
}
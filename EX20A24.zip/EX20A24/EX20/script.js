function MostraFeliz(imagem){
    imagem.src="imagens/Feliz.png";
}
function MostraTriste(imagem){
    imagem.src="imagens/Triste.png";
}
